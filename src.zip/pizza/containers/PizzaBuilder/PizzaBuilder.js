import React,{Component} from 'react';
import Aux from '../../hoc/Aux' ; 
import Pizza from '../../components/Pizza/Pizza';
import BuildControls from '../../components/Pizza/BuildControls/BuildControls';


const TOPPING_PRICE = {
  blackberry: 0.5,
  cheese:0.7,
  meat:1.3,
  bacon:0.7
}


class PizzaBuilder extends Component{
  state = {
     Toppings:{
    blackberry: 2,
    onion:0,
    
    meat : 1,
    cheese: 0
    }
    ,totalPrice:5




  }
  addToppingHandler = (type) =>{
   const oldCount = this.state.Toppings[type];
   const updatedCount = oldCount + 1;
   const updatedToppings = {
     ...this.state.Toppings 
   };
   updatedToppings[type] = updatedCount;
   const priceAddition = TOPPING_PRICE[type];
   const oldPrice = this.state.totalPrice;
   const newPrice = oldPrice + priceAddition;
   this.setState({totalPrice:newPrice,Toppings:updatedToppings})  

  }
  render(){
      return (
      <Aux>
         
         
         <Pizza Toppings = {this.state.Toppings}/>
          <BuildControls toppingsAdded={this.addToppingHandler}/>




      </Aux>



      );
    }
  }
  export default PizzaBuilder ;