import React from 'react';
import BuildControl from './BuildControl/BuildControl' ;
import classes from './BuildControls.module.css';
const controls = [
     {label:'Tomato', type:'tomato'},
     {label:'Blackberry',type:'blackberry'},
     {label:'Cheese',type:'cheese'}
     ,{label:'Meat',type:'meat'},
];




const buildControls = (props) =>(
    <div className={classes.BuildControls}>
      {controls.map(ctrl=>(<BuildControl 
      
      key = {ctrl.label} 
      label={ctrl.label}
      added={()=>props.toppingsAdded(ctrl.type)}/>

      ))


      }


    </div>
);

export default buildControls ;